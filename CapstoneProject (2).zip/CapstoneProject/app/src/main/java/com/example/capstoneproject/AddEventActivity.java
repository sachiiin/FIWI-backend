package com.example.capstoneproject;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.util.Calendar;

import okhttp3.MediaType;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddEventActivity extends AppCompatActivity {

    private static final String TAG = "AddEventActivity";

    private Button addEventButton, cancelButton;
    private EditText eventTitle, eventDescription, eventStartDatetime, eventEndDatetime, eventAddress, eventCity, eventState, eventZip;
    private Calendar eventCalendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        // Initialize UI components
        eventTitle = findViewById(R.id.event_title);
        eventDescription = findViewById(R.id.event_description);
        eventStartDatetime = findViewById(R.id.event_start_datetime);
        eventEndDatetime = findViewById(R.id.event_end_datetime);
        eventAddress = findViewById(R.id.event_address);
        eventCity = findViewById(R.id.event_city);
        eventState = findViewById(R.id.event_state);
        eventZip = findViewById(R.id.event_zip);
        addEventButton = findViewById(R.id.add_event_button);
        cancelButton = findViewById(R.id.cancel_button);
        eventCalendar = Calendar.getInstance();

        // Set up event listeners
        eventStartDatetime.setOnClickListener(v -> showDateTimePicker(eventStartDatetime));
        eventEndDatetime.setOnClickListener(v -> showDateTimePicker(eventEndDatetime));
        addEventButton.setOnClickListener(v -> {
            Log.d(TAG, "Attempting to add event");
            addEvent();
        });
        cancelButton.setOnClickListener(v -> {
            Intent intent = new Intent(AddEventActivity.this, HomeActivity.class);
            startActivity(intent);
            finish();
        });
    }

    private void showDateTimePicker(EditText editText) {
        final Calendar currentDate = Calendar.getInstance();
        eventCalendar = Calendar.getInstance();
        new DatePickerDialog(AddEventActivity.this, (view, year, monthOfYear, dayOfMonth) -> {
            eventCalendar.set(year, monthOfYear, dayOfMonth);
            new TimePickerDialog(AddEventActivity.this, (view1, hourOfDay, minute) -> {
                eventCalendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                eventCalendar.set(Calendar.MINUTE, minute);
                editText.setText(android.text.format.DateFormat.format("yyyy-MM-dd HH:mm", eventCalendar));
            }, currentDate.get(Calendar.HOUR_OF_DAY), currentDate.get(Calendar.MINUTE), false).show();
        }, currentDate.get(Calendar.YEAR), currentDate.get(Calendar.MONTH), currentDate.get(Calendar.DATE)).show();
    }

    private void addEvent() {
        String title = eventTitle.getText().toString().trim();
        String description = eventDescription.getText().toString().trim();
        String startDateTime = eventStartDatetime.getText().toString().trim();
        String endDateTime = eventEndDatetime.getText().toString().trim();
        String address = eventAddress.getText().toString().trim();
        String city = eventCity.getText().toString().trim();
        String state = eventState.getText().toString().trim();
        String zip = eventZip.getText().toString().trim();

        if (title.isEmpty() || description.isEmpty() || startDateTime.isEmpty() || endDateTime.isEmpty() ||
                address.isEmpty() || city.isEmpty() || state.isEmpty() || zip.isEmpty()) {
            Toast.makeText(this, "Please fill all the fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create the JSON request body
        String json = "{"
                + "\"title\":\"" + title + "\","
                + "\"description\":\"" + description + "\","
                + "\"start_date\":\"" + startDateTime + "\","
                + "\"end_date\":\"" + endDateTime + "\","
                + "\"address\":\"" + address + "\","
                + "\"city\":\"" + city + "\","
                + "\"state\":\"" + state + "\","
                + "\"zip\":\"" + zip + "\","
                + "\"status\":\"Approved\""
                + "}";

        RequestBody requestBody = RequestBody.create(MediaType.parse("application/json"), json);

        ApiService apiService = RetrofitClient.getClient().create(ApiService.class);
        Call<Event> call = apiService.createEventWithoutImage(requestBody);
        call.enqueue(new Callback<Event>() {
            @Override
            public void onResponse(Call<Event> call, Response<Event> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(AddEventActivity.this, "Event added successfully", Toast.LENGTH_SHORT).show();
                    Event event = response.body();
                    Intent intent = new Intent(AddEventActivity.this, HomeActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    try {
                        Log.e(TAG, "Failed to add event: " + response.errorBody().string());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    Toast.makeText(AddEventActivity.this, "Failed to add event", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Event> call, Throwable t) {
                Log.e(TAG, "Network error: " + t.getMessage());
                Toast.makeText(AddEventActivity.this, "Network error", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
