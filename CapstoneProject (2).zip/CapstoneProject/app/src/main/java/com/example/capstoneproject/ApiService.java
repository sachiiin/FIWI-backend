package com.example.capstoneproject;

import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Path;
import java.util.List;

public interface ApiService {
    @POST("users/register")
    Call<User> registerUser(@Body User user);

    @POST("users/signin")
    Call<User> signInUser(@Body User user);

    @POST("events")
    Call<Event> createEventWithoutImage(@Body RequestBody eventData);

    @POST("favorites/add")
    Call<Void> addFavorite(@Body FavoriteRequest request);

    @DELETE("favorites/remove/{eventId}")
    Call<Void> removeFavorite(@Path("eventId") String eventId);

    @GET("events")
    Call<List<Event>> getEvents(); // Add this method to fetch events from the database
}
