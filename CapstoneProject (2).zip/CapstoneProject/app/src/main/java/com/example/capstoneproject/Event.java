package com.example.capstoneproject;

import java.io.Serializable;

public class Event implements Serializable {
    private String id;
    private String title;
    private String description;
    private String start_date;
    private String end_date;
    private Location location;
    private String status;
    private String created_at;
    private String image;
    private boolean isFavorite;
    private String organizer;

    public Event(String id, String title, String description, String start_date, String end_date, Location location, String status, String created_at, String image, String organizer) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.start_date = start_date;
        this.end_date = end_date;
        this.location = location;
        this.status = status;
        this.created_at = created_at;
        this.image = image;
        this.organizer = organizer;
    }

    // Getters and Setters for all fields, including isFavorite
    public boolean isFavorite() {
        return isFavorite;
    }

    public void setFavorite(boolean favorite) {
        isFavorite = favorite;
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getStartDate() {
        return start_date;
    }

    public String getEndDate() {
        return end_date;
    }

    public Location getLocation() {
        return location;
    }

    public String getStatus() {
        return status;
    }

    public String getCreatedAt() {
        return created_at;
    }

    public String getImage() {
        return image;
    }

    public String getOrganizer() {
        return organizer;
    }

    // Inner class for Location
    public static class Location implements Serializable {
        private String address;
        private String city;
        private String state;
        private String zip;

        public Location(String address, String city, String state, String zip) {
            this.address = address;
            this.city = city;
            this.state = state;
            this.zip = zip;
        }

        public String getAddress() {
            return address;
        }

        public String getCity() {
            return city;
        }

        public String getState() {
            return state;
        }

        public String getZip() {
            return zip;
        }
    }
}
