package com.example.capstoneproject;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {

    private List<Event> eventList;
    private final OnFavoriteClickListener onFavoriteClickListener;
    private Context context;

    public EventAdapter(List<Event> eventList, OnFavoriteClickListener onFavoriteClickListener) {
        this.eventList = eventList;
        this.onFavoriteClickListener = onFavoriteClickListener;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        // Inflate the item_event layout
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_event, parent, false);
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        // Bind the data to the views
        Event event = eventList.get(position);

        // Always use the dummy image
        holder.eventImage.setImageResource(R.drawable.eventposter);

        // Format and set the event dates
        String formattedStartDate = formatDate(event.getStartDate());
        String formattedEndDate = formatDate(event.getEndDate());
        holder.eventDateTime.setText(formattedStartDate + " - " + formattedEndDate);

        holder.eventTitle.setText(event.getTitle());
        holder.eventDescription.setText(event.getDescription());
        holder.eventLocation.setText(event.getLocation().getAddress() + ", " + event.getLocation().getCity() + ", " + event.getLocation().getState() + " " + event.getLocation().getZip());

        // Update favorite icon
        if (FavoriteManager.getInstance().isFavorite(event)) {
            holder.btnFavorite.setImageResource(R.drawable.ic_favorite); // Checked icon
        } else {
            holder.btnFavorite.setImageResource(R.drawable.ic_favorite_uncheckedx); // Unchecked icon
        }

        // Set favorite button click listener
        holder.btnFavorite.setOnClickListener(v -> {
            boolean isFavorite = !FavoriteManager.getInstance().isFavorite(event);
            if (isFavorite) {
                FavoriteManager.getInstance().addFavorite(event);
            } else {
                FavoriteManager.getInstance().removeFavorite(event);
            }
            notifyItemChanged(position);
        });

        // Set event title click listener
        holder.eventTitle.setOnClickListener(v -> {
            Intent intent = new Intent(context, EventDetailsActivity.class);
            intent.putExtra("event", event); // Pass the event object
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }

    public void updateData(List<Event> newEventList) {
        this.eventList = newEventList;
        notifyDataSetChanged();
    }

    public static class EventViewHolder extends RecyclerView.ViewHolder {
        ImageView eventImage;
        TextView eventDateTime;
        TextView eventTitle;
        TextView eventDescription;
        TextView eventLocation;
        ImageButton btnFavorite;
        ImageButton btnShare;

        public EventViewHolder(@NonNull View itemView) {
            super(itemView);
            eventImage = itemView.findViewById(R.id.event_image);
            eventDateTime = itemView.findViewById(R.id.event_datetime);
            eventTitle = itemView.findViewById(R.id.event_title);
            eventDescription = itemView.findViewById(R.id.event_description);
            eventLocation = itemView.findViewById(R.id.event_location);
            btnFavorite = itemView.findViewById(R.id.btn_favorite);
            btnShare = itemView.findViewById(R.id.btn_share);
        }
    }

    public interface OnFavoriteClickListener {
        void onFavoriteClick(Event event);
    }

    // Helper method to format the date
    private String formatDate(String dateString) {
        SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.getDefault());
        SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MM-yy EEE, h:mm a", Locale.getDefault());
        try {
            Date date = inputFormat.parse(dateString);
            return outputFormat.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
            return dateString;
        }
    }
}
