package com.example.capstoneproject;

import android.content.Intent;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class EventDetailsActivity extends AppCompatActivity {

    private static final String TAG = "EventDetailsActivity";
    private TextView titleTextView, descriptionTextView, dateTextView, locationTextView, organizerTextView;
    private ImageView eventImageView, backArrow, saveIcon, shareIcon;
    private boolean isFavorite;
    private Event event;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eventdetails);

        // Initialize views
        eventImageView = findViewById(R.id.event_image);
        titleTextView = findViewById(R.id.event_title);
        descriptionTextView = findViewById(R.id.event_description);
        dateTextView = findViewById(R.id.calendar_text);
        locationTextView = findViewById(R.id.location_text);
        organizerTextView = findViewById(R.id.organizer_text);
        backArrow = findViewById(R.id.back_arrow);
        saveIcon = findViewById(R.id.save_icon);
        shareIcon = findViewById(R.id.share_icon);

        // Get the event object from the intent
        event = (Event) getIntent().getSerializableExtra("event");

        // Set the event details to the views
        if (event != null) {
            Log.d(TAG, "Event details: " + event.toString());
            // Always use the dummy image
            eventImageView.setImageResource(R.drawable.eventposter);

            titleTextView.setText(event.getTitle());
            descriptionTextView.setText(event.getDescription());
            dateTextView.setText(event.getStartDate() + "\n" + formatDate(event.getStartDate()));
            locationTextView.setText(event.getLocation().getAddress() + ", " + event.getLocation().getCity() + ", " + event.getLocation().getState() + " " + event.getLocation().getZip());
            organizerTextView.setText((event.getOrganizer() != null ? event.getOrganizer() : "Unknown") + "\nOrganizer");

            // Set initial favorite state
            isFavorite = FavoriteManager.getInstance().isFavorite(event);
            updateFavoriteIcon(isFavorite);

            // Set favorite button click listener
            saveIcon.setOnClickListener(v -> {
                isFavorite = !isFavorite;
                if (isFavorite) {
                    FavoriteManager.getInstance().addFavorite(event);
                } else {
                    FavoriteManager.getInstance().removeFavorite(event);
                }
                updateFavoriteIcon(isFavorite);
            });
        } else {
            Log.e(TAG, "Event is null");
        }

        // Back arrow functionality
        backArrow.setOnClickListener(v -> onBackPressed());

        // Add to calendar functionality
        FloatingActionButton addToCalendarButton = findViewById(R.id.fab_add_to_calendar);
        addToCalendarButton.setOnClickListener(v -> {
            if (event != null) {
                Calendar beginTime = Calendar.getInstance();
                Calendar endTime = Calendar.getInstance();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.getDefault());

                try {
                    Date startDate = sdf.parse(event.getStartDate());
                    Date endDate = sdf.parse(event.getEndDate());

                    if (startDate != null) {
                        beginTime.setTime(startDate);
                    }
                    if (endDate != null) {
                        endTime.setTime(endDate);
                    }

                    Intent intent = new Intent(Intent.ACTION_INSERT)
                            .setData(CalendarContract.Events.CONTENT_URI)
                            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, beginTime.getTimeInMillis())
                            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, endTime.getTimeInMillis())
                            .putExtra(CalendarContract.Events.TITLE, event.getTitle())
                            .putExtra(CalendarContract.Events.DESCRIPTION, event.getDescription())
                            .putExtra(CalendarContract.Events.EVENT_LOCATION, event.getLocation().getAddress() + ", " + event.getLocation().getCity() + ", " + event.getLocation().getState() + " " + event.getLocation().getZip())
                            .putExtra(CalendarContract.Events.AVAILABILITY, CalendarContract.Events.AVAILABILITY_BUSY);
                    startActivity(intent);

                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private String formatDate(String dateString) {
        SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.getDefault());
        SimpleDateFormat outputFormat = new SimpleDateFormat("dd MMM, yyyy\nEEEE, h:mm a", Locale.getDefault());
        Date date;
        String formattedDate = "";
        try {
            date = inputFormat.parse(dateString);
            if (date != null) {
                formattedDate = outputFormat.format(date);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return formattedDate;
    }

    private void updateFavoriteIcon(boolean isFavorite) {
        if (isFavorite) {
            saveIcon.setImageResource(R.drawable.ic_favorite);
        } else {
            saveIcon.setImageResource(R.drawable.ic_favorite_uncheckedx);
        }
    }
}
