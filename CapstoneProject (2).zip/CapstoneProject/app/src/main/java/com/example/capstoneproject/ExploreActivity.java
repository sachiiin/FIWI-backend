package com.example.capstoneproject;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ExploreActivity extends AppCompatActivity implements EventAdapter.OnFavoriteClickListener {

    private Button selectDateButton;
    private RecyclerView recyclerView;
    private EventAdapter eventAdapter;
    private List<Event> eventList;
    private List<Event> filteredList;
    private BottomNavigationView bottomNavigationView;
    private EditText searchBar;
    private ActivityResultLauncher<String[]> requestPermissionsLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_explorepage);

        // Register the activity result launcher for permission requests
        requestPermissionsLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestMultiplePermissions(),
                result -> {
                    for (Map.Entry<String, Boolean> entry : result.entrySet()) {
                        String permission = entry.getKey();
                        Boolean isGranted = entry.getValue();
                        if (isGranted) {
                            // Permission is granted
                            Toast.makeText(this, permission + " granted", Toast.LENGTH_SHORT).show();
                        } else {
                            // Permission is denied
                            Toast.makeText(this, permission + " denied", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
        );

        // Request permissions if needed
        requestPermissionsIfNeeded();

        selectDateButton = findViewById(R.id.btn_select_date);
        recyclerView = findViewById(R.id.recycler_view);
        bottomNavigationView = findViewById(R.id.bottom_navigation);
        searchBar = findViewById(R.id.search_bar);

        selectDateButton.setOnClickListener(view -> showDatePickerDialog());

        // Set up RecyclerView with GridLayoutManager
        eventList = new ArrayList<>(); // Initialize with an empty list
        filteredList = new ArrayList<>(eventList);
        eventAdapter = new EventAdapter(filteredList, this);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2)); // 2 columns
        recyclerView.setAdapter(eventAdapter);

        // Handle bottom navigation item selection
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.navigation_home) {
                // Navigate to HomeActivity
                startActivity(new Intent(ExploreActivity.this, HomeActivity.class));
                return true;
            } else if (itemId == R.id.navigation_explore) {
                // Handle explore action
                return true;
            } else if (itemId == R.id.navigation_favourites) {
                // Navigate to FavouriteActivity
                startActivity(new Intent(ExploreActivity.this, FavouriteActivity.class));
                return true;
            }
            return false;
        });

        // Add TextWatcher to search bar
        searchBar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                fetchAndFilterEvents(charSequence.toString(), null, null);
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });

        // Location buttons click listeners
        findViewById(R.id.btn_toronto).setOnClickListener(v -> fetchAndFilterEvents(null, "Toronto", null));
        findViewById(R.id.btn_mississauga).setOnClickListener(v -> fetchAndFilterEvents(null, "Mississauga", null));
        findViewById(R.id.btn_brampton).setOnClickListener(v -> fetchAndFilterEvents(null, "Brampton", null));
        findViewById(R.id.btn_Etobicoke).setOnClickListener(v -> fetchAndFilterEvents(null, "Etobicoke", null));

        // Date buttons click listeners
        findViewById(R.id.btn_today).setOnClickListener(v -> fetchAndFilterEvents(null, null, "Today"));
        findViewById(R.id.btn_tomorrow).setOnClickListener(v -> fetchAndFilterEvents(null, null, "Tomorrow"));
        findViewById(R.id.btn_this_week).setOnClickListener(v -> fetchAndFilterEvents(null, null, "This Week"));
        findViewById(R.id.btn_this_month).setOnClickListener(v -> fetchAndFilterEvents(null, null, "This Month"));
    }

    private void fetchAndFilterEvents(String searchText, String location, String dateRange) {
        ApiService apiService = RetrofitClient.getClient().create(ApiService.class);

        apiService.getEvents().enqueue(new Callback<List<Event>>() {
            @Override
            public void onResponse(Call<List<Event>> call, Response<List<Event>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    eventList = response.body();
                    filterEvents(searchText, location, dateRange);
                } else {
                    Toast.makeText(ExploreActivity.this, "Failed to load events", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Event>> call, Throwable t) {
                Toast.makeText(ExploreActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void filterEvents(String searchText, String location, String dateRange) {
        filteredList.clear();

        for (Event event : eventList) {
            boolean matchesSearch = searchText == null || event.getTitle().toLowerCase().contains(searchText.toLowerCase()) || event.getLocation().getCity().toLowerCase().contains(searchText.toLowerCase());
            boolean matchesLocation = location == null || event.getLocation().getCity().equalsIgnoreCase(location);
            boolean matchesDate = dateRange == null || matchesDateRange(event.getStartDate(), dateRange);

            if (matchesSearch && matchesLocation && matchesDate) {
                filteredList.add(event);
            }
        }

        eventAdapter.updateData(filteredList);
    }

    private boolean matchesDateRange(String eventDate, String dateRange) {
        Calendar calendar = Calendar.getInstance();
        long currentTime = calendar.getTimeInMillis();

        switch (dateRange) {
            case "Today":
                return isToday(eventDate);
            case "Tomorrow":
                return isTomorrow(eventDate);
            case "This Week":
                return isThisWeek(eventDate);
            case "This Month":
                return isThisMonth(eventDate);
        }
        return false;
    }

    private boolean isToday(String eventDate) {
        Calendar calendar = Calendar.getInstance();
        String today = calendar.get(Calendar.YEAR) + "-" + (calendar.get(Calendar.MONTH) + 1) + "-" + calendar.get(Calendar.DAY_OF_MONTH);
        return eventDate.contains(today);
    }

    private boolean isTomorrow(String eventDate) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        String tomorrow = calendar.get(Calendar.YEAR) + "-" + (calendar.get(Calendar.MONTH) + 1) + "-" + calendar.get(Calendar.DAY_OF_MONTH);
        return eventDate.contains(tomorrow);
    }

    private boolean isThisWeek(String eventDate) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
        long weekStart = calendar.getTimeInMillis();
        calendar.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY);
        long weekEnd = calendar.getTimeInMillis();
        long eventTime = convertDateStringToMillis(eventDate);
        return eventTime >= weekStart && eventTime <= weekEnd;
    }

    private boolean isThisMonth(String eventDate) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        long monthStart = calendar.getTimeInMillis();
        calendar.add(Calendar.MONTH, 1);
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        calendar.add(Calendar.DAY_OF_MONTH, -1);
        long monthEnd = calendar.getTimeInMillis();
        long eventTime = convertDateStringToMillis(eventDate);
        return eventTime >= monthStart && eventTime <= monthEnd;
    }

    private long convertDateStringToMillis(String dateString) {
        // Convert date string to milliseconds for comparison
        Calendar calendar = Calendar.getInstance();
        String[] parts = dateString.split("-");
        int year = Integer.parseInt(parts[0]);
        int month = Integer.parseInt(parts[1]) - 1; // Calendar months are 0-based
        int day = Integer.parseInt(parts[2].split("T")[0]);
        calendar.set(year, month, day);
        return calendar.getTimeInMillis();
    }

    private void showDatePickerDialog() {
        // Get current date
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        // Create and show DatePickerDialog
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                ExploreActivity.this,
                (view, year1, monthOfYear, dayOfMonth) -> {
                    // Format the selected date to match the expected event date format
                    String selectedDate = String.format("%04d-%02d-%02d", year1, monthOfYear + 1, dayOfMonth);
                    selectDateButton.setText(selectedDate);
                    fetchAndFilterEvents(null, null, selectedDate);
                },
                year, month, day);
        datePickerDialog.show();
    }

    @Override
    public void onFavoriteClick(Event event) {
        if (FavoriteManager.getInstance().isFavorite(event)) {
            FavoriteManager.getInstance().removeFavorite(event);
        } else {
            FavoriteManager.getInstance().addFavorite(event);
        }
        // Update filteredList to reflect favorite changes
        fetchAndFilterEvents(searchBar.getText().toString(), null, null);
    }

    private void requestPermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            requestPermissionsLauncher.launch(new String[]{
                    Manifest.permission.READ_MEDIA_IMAGES,
                    Manifest.permission.READ_MEDIA_VIDEO,
                    "android.permission.READ_MEDIA_VISUAL_USER_SELECTED"
            });
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissionsLauncher.launch(new String[]{
                    Manifest.permission.READ_MEDIA_IMAGES,
                    Manifest.permission.READ_MEDIA_VIDEO
            });
        } else {
            requestPermissionsLauncher.launch(new String[]{
                    Manifest.permission.READ_EXTERNAL_STORAGE
            });
        }
    }
}
