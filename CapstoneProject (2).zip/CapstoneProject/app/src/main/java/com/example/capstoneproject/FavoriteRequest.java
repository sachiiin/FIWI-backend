package com.example.capstoneproject;

public class FavoriteRequest {
    private String userId;
    private String eventId;

    public FavoriteRequest(String userId, String eventId) {
        this.userId = userId;
        this.eventId = eventId;
    }

    // Getters and setters
}
