package com.example.capstoneproject;

import android.Manifest;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class FavouriteActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private EventAdapter adapter;
    private List<Event> favoriteEventList;
    private EditText searchBar;
    private ActivityResultLauncher<String[]> requestPermissionsLauncher;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourites);

        // Register the activity result launcher for permission requests
        requestPermissionsLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestMultiplePermissions(),
                result -> {
                    for (Map.Entry<String, Boolean> entry : result.entrySet()) {
                        String permission = entry.getKey();
                        Boolean isGranted = entry.getValue();
                        if (isGranted) {
                            // Permission is granted
                            Toast.makeText(this, permission + " granted", Toast.LENGTH_SHORT).show();
                        } else {
                            // Permission is denied
                            Toast.makeText(this, permission + " denied", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
        );

        // Request permissions if needed
        requestPermissionsIfNeeded();

        searchBar = findViewById(R.id.search_bar);
        recyclerView = findViewById(R.id.recycler_view);
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        // Initialize event list and adapter
        favoriteEventList = new ArrayList<>(FavoriteManager.getInstance().getFavorites());
        adapter = new EventAdapter(favoriteEventList, event -> {
            if (FavoriteManager.getInstance().isFavorite(event)) {
                FavoriteManager.getInstance().removeFavorite(event);
            } else {
                FavoriteManager.getInstance().addFavorite(event);
            }
            adapter.updateData(new ArrayList<>(FavoriteManager.getInstance().getFavorites()));
        });

        // Setup RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // Bottom Navigation setup
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.navigation_home) {
                // Navigate to Home
                startActivity(new Intent(FavouriteActivity.this, HomeActivity.class));
                return true;
            } else if (itemId == R.id.navigation_explore) {
                // Navigate to Explore
                startActivity(new Intent(FavouriteActivity.this, ExploreActivity.class));
                return true;
            } else if (itemId == R.id.navigation_favourites) {
                // Stay in Favourites
                return true;
            }
            return false;
        });

        // Add TextWatcher to search bar
        searchBar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                filter(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
    }

    private void filter(String text) {
        List<Event> filteredList = new ArrayList<>();
        for (Event event : favoriteEventList) {
            if (event.getTitle().toLowerCase().contains(text.toLowerCase()) ||
                    event.getLocation().getCity().toLowerCase().contains(text.toLowerCase())) {
                filteredList.add(event);
            }
        }
        adapter.updateData(filteredList);
    }

    private void requestPermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            requestPermissionsLauncher.launch(new String[]{
                    Manifest.permission.READ_MEDIA_IMAGES,
                    Manifest.permission.READ_MEDIA_VIDEO,
                    "android.permission.READ_MEDIA_VISUAL_USER_SELECTED"
            });
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissionsLauncher.launch(new String[]{
                    Manifest.permission.READ_MEDIA_IMAGES,
                    Manifest.permission.READ_MEDIA_VIDEO
            });
        } else {
            requestPermissionsLauncher.launch(new String[]{
                    Manifest.permission.READ_EXTERNAL_STORAGE
            });
        }
    }
}
