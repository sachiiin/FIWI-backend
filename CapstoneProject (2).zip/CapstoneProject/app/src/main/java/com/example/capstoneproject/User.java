package com.example.capstoneproject;

public class User {
    private String first_name;
    private String last_name;
    private String email;
    private String password;

    public User(String first_name, String last_name, String email, String password) {
        this.first_name = first_name;
        this.last_name = last_name;
        this.email = email;
        this.password = password;
    }

    // Getter for first_name
    public String getFirstName() {
        return first_name;
    }

    // Setter for first_name
    public void setFirstName(String first_name) {
        this.first_name = first_name;
    }

    // Getter for last_name
    public String getLastName() {
        return last_name;
    }

    // Setter for last_name
    public void setLastName(String last_name) {
        this.last_name = last_name;
    }

    // Getter for email
    public String getEmail() {
        return email;
    }

    // Setter for email
    public void setEmail(String email) {
        this.email = email;
    }

    // Getter for password
    public String getPassword() {
        return password;
    }

    // Setter for password
    public void setPassword(String password) {
        this.password = password;
    }
}
