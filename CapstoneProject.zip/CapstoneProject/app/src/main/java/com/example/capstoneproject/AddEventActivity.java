package com.example.capstoneproject;

import android.Manifest;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Calendar;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddEventActivity extends AppCompatActivity {

    private static final String TAG = "AddEventActivity";
    private static final int PICK_IMAGE_REQUEST = 1;
    private static final int STORAGE_PERMISSION_CODE = 101;
    private Button buttonUploadBrochure, addEventButton, cancelButton;
    private EditText eventTitle, eventDescription, eventStartDatetime, eventEndDatetime, eventAddress, eventCity, eventState, eventZip;
    private Calendar eventCalendar;
    private Uri imageUri;
    private String userId;
    private ImageView imageViewPreview;
    private ActivityResultLauncher<String[]> requestPermissionsLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        // Register the activity result launcher for permission requests
        requestPermissionsLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestMultiplePermissions(),
                result -> {
                    for (Map.Entry<String, Boolean> entry : result.entrySet()) {
                        String permission = entry.getKey();
                        Boolean isGranted = entry.getValue();
                        if (isGranted) {
                            // Permission is granted
                            Toast.makeText(this, permission + " granted", Toast.LENGTH_SHORT).show();
                        } else {
                            // Permission is denied
                            Toast.makeText(this, permission + " denied", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
        );

        // Request permissions if needed
        requestPermissionsIfNeeded();

        buttonUploadBrochure = findViewById(R.id.button_upload_brochure);
        eventTitle = findViewById(R.id.event_title);
        eventDescription = findViewById(R.id.event_description);
        eventStartDatetime = findViewById(R.id.event_start_datetime);
        eventEndDatetime = findViewById(R.id.event_end_datetime);
        eventAddress = findViewById(R.id.event_address);
        eventCity = findViewById(R.id.event_city);
        eventState = findViewById(R.id.event_state);
        eventZip = findViewById(R.id.event_zip);
        addEventButton = findViewById(R.id.add_event_button);
        cancelButton = findViewById(R.id.cancel_button);
        imageViewPreview = findViewById(R.id.image_view_preview);
        eventCalendar = Calendar.getInstance();

        userId = getIntent().getStringExtra("USER_ID");

        eventStartDatetime.setOnClickListener(v -> showDateTimePicker(eventStartDatetime));
        eventEndDatetime.setOnClickListener(v -> showDateTimePicker(eventEndDatetime));
        buttonUploadBrochure.setOnClickListener(v -> openFileChooser());
        addEventButton.setOnClickListener(v -> addEvent());
        cancelButton.setOnClickListener(v -> {
            Intent intent = new Intent(AddEventActivity.this, HomeActivity.class);
            startActivity(intent);
            finish();
        });

        // Check for storage permission
        if (!checkPermission(Manifest.permission.READ_EXTERNAL_STORAGE, STORAGE_PERMISSION_CODE)) {
            requestPermission(Manifest.permission.READ_EXTERNAL_STORAGE, STORAGE_PERMISSION_CODE);
        }
    }

    private void showDateTimePicker(EditText editText) {
        final Calendar currentDate = Calendar.getInstance();
        eventCalendar = Calendar.getInstance();
        new DatePickerDialog(AddEventActivity.this, (view, year, monthOfYear, dayOfMonth) -> {
            eventCalendar.set(year, monthOfYear, dayOfMonth);
            new TimePickerDialog(AddEventActivity.this, (view1, hourOfDay, minute) -> {
                eventCalendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                eventCalendar.set(Calendar.MINUTE, minute);
                editText.setText(android.text.format.DateFormat.format("yyyy-MM-dd HH:mm", eventCalendar));
            }, currentDate.get(Calendar.HOUR_OF_DAY), currentDate.get(Calendar.MINUTE), false).show();
        }, currentDate.get(Calendar.YEAR), currentDate.get(Calendar.MONTH), currentDate.get(Calendar.DATE)).show();
    }

    private void openFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();
            buttonUploadBrochure.setText("Brochure Uploaded");

            // Display the selected image using Glide
            Glide.with(this)
                    .load(imageUri)
                    .into(imageViewPreview);
        }
    }

    private void addEvent() {
        String title = eventTitle.getText().toString().trim();
        String description = eventDescription.getText().toString().trim();
        String startDateTime = eventStartDatetime.getText().toString().trim();
        String endDateTime = eventEndDatetime.getText().toString().trim();
        String address = eventAddress.getText().toString().trim();
        String city = eventCity.getText().toString().trim();
        String state = eventState.getText().toString().trim();
        String zip = eventZip.getText().toString().trim();

        if (title.isEmpty() || description.isEmpty() || startDateTime.isEmpty() || endDateTime.isEmpty() ||
                address.isEmpty() || city.isEmpty() || state.isEmpty() || zip.isEmpty() || imageUri == null) {
            Toast.makeText(this, "Please fill all the fields and upload an image", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            InputStream inputStream = getContentResolver().openInputStream(imageUri);
            if (inputStream == null) {
                Toast.makeText(this, "Failed to open image input stream", Toast.LENGTH_SHORT).show();
                return;
            }

            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                byteArrayOutputStream.write(buffer, 0, bytesRead);
            }
            byte[] imageData = byteArrayOutputStream.toByteArray();
            String fileName = getFileName(imageUri);

            RequestBody requestFile = RequestBody.create(MediaType.parse(getContentResolver().getType(imageUri)), imageData);
            MultipartBody.Part body = MultipartBody.Part.createFormData("image", fileName, requestFile);

            RequestBody titleBody = RequestBody.create(MultipartBody.FORM, title);
            RequestBody descriptionBody = RequestBody.create(MultipartBody.FORM, description);
            RequestBody startDateTimeBody = RequestBody.create(MultipartBody.FORM, startDateTime);
            RequestBody endDateTimeBody = RequestBody.create(MultipartBody.FORM, endDateTime);
            RequestBody addressBody = RequestBody.create(MultipartBody.FORM, address);
            RequestBody cityBody = RequestBody.create(MultipartBody.FORM, city);
            RequestBody stateBody = RequestBody.create(MultipartBody.FORM, state);
            RequestBody zipBody = RequestBody.create(MultipartBody.FORM, zip);
            RequestBody statusBody = RequestBody.create(MultipartBody.FORM, "Approved");
            RequestBody userIdBody = RequestBody.create(MultipartBody.FORM, userId);

            ApiService apiService = RetrofitClient.getClient().create(ApiService.class);
            Call<Event> call = apiService.createEvent(body, titleBody, descriptionBody, startDateTimeBody, endDateTimeBody, addressBody, cityBody, stateBody, zipBody, statusBody, userIdBody);
            call.enqueue(new Callback<Event>() {
                @Override
                public void onResponse(Call<Event> call, Response<Event> response) {
                    if (response.isSuccessful()) {
                        Toast.makeText(AddEventActivity.this, "Event added successfully", Toast.LENGTH_SHORT).show();
                        Event event = response.body();
                        if (event != null && event.getImage() != null) {
                            // Construct the image URL using the image ID from the event
                            String imageUrl = RetrofitClient.BASE_URL + "image/" + event.getImage();
                            Log.d(TAG, "Image URL: " + imageUrl);

                            // Use Glide to display the uploaded image
                            Glide.with(AddEventActivity.this)
                                    .load(imageUrl)
                                    .into(imageViewPreview);
                        }
                        Intent intent = new Intent(AddEventActivity.this, HomeActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        Log.e(TAG, "Failed to add event: " + response.message());
                        Toast.makeText(AddEventActivity.this, "Failed to add event", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<Event> call, Throwable t) {
                    Log.e(TAG, "Network error: " + t.getMessage());
                    Toast.makeText(AddEventActivity.this, "Network error", Toast.LENGTH_SHORT).show();
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to upload image", Toast.LENGTH_SHORT).show();
        }
    }

    private String getFileName(Uri uri) {
        String result = null;
        if (uri.getScheme().equals("content")) {
            Cursor cursor = getContentResolver().query(uri, null, null, null, null);
            try {
                if (cursor != null && cursor.moveToFirst()) {
                    int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (nameIndex >= 0) {
                        result = cursor.getString(nameIndex);
                    } else {
                        Log.e(TAG, "DISPLAY_NAME column not found");
                    }
                }
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        if (result == null) {
            result = uri.getPath();
            int cut = result.lastIndexOf('/');
            if (cut != -1) {
                result = result.substring(cut + 1);
            }
        }
        return result;
    }

    // Method to check permission
    private boolean checkPermission(String permission, int requestCode) {
        if (ContextCompat.checkSelfPermission(AddEventActivity.this, permission)
                == PackageManager.PERMISSION_DENIED) {

            // Requesting the permission
            ActivityCompat.requestPermissions(AddEventActivity.this,
                    new String[]{permission},
                    requestCode);
            return false;
        } else {
            return true;
        }
    }

    // Method to request permission
    private void requestPermission(String permission, int requestCode) {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
            // Explain to the user why the permission is necessary
            Toast.makeText(this, "Storage permission is required to select images", Toast.LENGTH_SHORT).show();
        }
        ActivityCompat.requestPermissions(this, new String[]{permission}, requestCode);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(AddEventActivity.this,
                                "Storage Permission Granted",
                                Toast.LENGTH_SHORT)
                        .show();
            } else {
                Toast.makeText(AddEventActivity.this,
                                "Storage Permission Denied",
                                Toast.LENGTH_SHORT)
                        .show();
            }
        }
    }

    private void requestPermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            requestPermissionsLauncher.launch(new String[]{
                    Manifest.permission.READ_MEDIA_IMAGES,
                    Manifest.permission.READ_MEDIA_VIDEO,
                    "android.permission.READ_MEDIA_VISUAL_USER_SELECTED"
            });
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissionsLauncher.launch(new String[]{
                    Manifest.permission.READ_MEDIA_IMAGES,
                    Manifest.permission.READ_MEDIA_VIDEO
            });
        } else {
            requestPermissionsLauncher.launch(new String[]{
                    Manifest.permission.READ_EXTERNAL_STORAGE
            });
        }
    }
}
