package com.example.capstoneproject;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;
import retrofit2.http.DELETE;
import java.util.List;

public interface ApiService {
    @POST("register")
    Call<User> registerUser(@Body User user);

    @POST("signin")
    Call<User> signInUser(@Body User user);

    @Multipart
    @POST("events")
    Call<Event> createEvent(
            @Part MultipartBody.Part image,
            @Part("title") RequestBody title,
            @Part("description") RequestBody description,
            @Part("start_date") RequestBody startDate,
            @Part("end_date") RequestBody endDate,
            @Part("address") RequestBody address,
            @Part("city") RequestBody city,
            @Part("state") RequestBody state,
            @Part("zip") RequestBody zip,
            @Part("status") RequestBody status,
            @Part("userid") RequestBody userId
    );

    @POST("favorites/add")
    Call<Void> addFavorite(@Body FavoriteRequest request);

    @DELETE("favorites/remove/{eventId}")
    Call<Void> removeFavorite(@Path("eventId") String eventId);

    @GET("events")
    Call<List<Event>> getEvents(); // Add this method to fetch events from the database
}