package com.example.capstoneproject;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class ConfirmOtpActivity extends AppCompatActivity {

    private EditText editTextOtp;
    private Button buttonConfirm;
    private String generatedOtp;
    private String userEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_otp);

        editTextOtp = findViewById(R.id.editTextOtp);
        buttonConfirm = findViewById(R.id.buttonConfirm);

        // Retrieve the email passed from MainActivity
        userEmail = getIntent().getStringExtra("USER_EMAIL");

        if (userEmail == null) {
            Toast.makeText(this, "No email provided", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Generate and send OTP
        generatedOtp = generateOtp();
        sendOtpEmail(userEmail, generatedOtp);

        buttonConfirm.setOnClickListener(view -> {
            String otp = editTextOtp.getText().toString().trim();

            if (TextUtils.isEmpty(otp)) {
                Toast.makeText(ConfirmOtpActivity.this, "Please enter OTP", Toast.LENGTH_SHORT).show();
                return;
            }

            if (otp.equals(generatedOtp)) {
                Intent intent = new Intent(ConfirmOtpActivity.this, SignInActivity.class);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(ConfirmOtpActivity.this, "Invalid OTP", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private String generateOtp() {
        Random random = new Random();
        int otp = 100000 + random.nextInt(900000);
        return String.valueOf(otp);
    }

    private void sendOtpEmail(String email, String otp) {
        new Thread(() -> {
            String subject = "Your OTP Code";
            String message = "Your OTP Code For Registration is: " + otp;
            EmailSender.sendEmail(email, subject, message);
        }).start();
    }
}
