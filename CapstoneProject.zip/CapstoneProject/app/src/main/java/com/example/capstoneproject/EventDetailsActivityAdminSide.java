package com.example.capstoneproject;

import android.app.Activity;

public class EventDetailsActivityAdminSide extends Activity {
}
