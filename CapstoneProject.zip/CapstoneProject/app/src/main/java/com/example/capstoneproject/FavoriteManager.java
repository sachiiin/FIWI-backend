package com.example.capstoneproject;

import java.util.HashSet;
import java.util.Set;

public class FavoriteManager {

    private static FavoriteManager instance;
    private Set<Event> favoriteEvents;

    private FavoriteManager() {
        favoriteEvents = new HashSet<>();
    }

    public static synchronized FavoriteManager getInstance() {
        if (instance == null) {
            instance = new FavoriteManager();
        }
        return instance;
    }

    public void addFavorite(Event event) {
        favoriteEvents.add(event);
    }

    public void removeFavorite(Event event) {
        favoriteEvents.remove(event);
    }

    public Set<Event> getFavorites() {
        return favoriteEvents;
    }

    public boolean isFavorite(Event event) {
        return favoriteEvents.contains(event);
    }
}

