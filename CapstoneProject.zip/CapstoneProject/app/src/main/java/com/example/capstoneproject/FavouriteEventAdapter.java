package com.example.capstoneproject;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class FavouriteEventAdapter extends RecyclerView.Adapter<FavouriteEventAdapter.FavouriteEventViewHolder> {

    private final List<Event> eventList;

    public FavouriteEventAdapter(FavouriteActivity favouriteActivity, List<Event> eventList) {
        this.eventList = eventList;
    }

    @NonNull
    @Override
    public FavouriteEventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_favorite_event, parent, false);
        return new FavouriteEventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FavouriteEventViewHolder holder, int position) {
        Event event = eventList.get(position);
        Glide.with(holder.itemView.getContext()).load(event.getImage()).into(holder.eventImage);
        holder.eventDateTime.setText(event.getStartDate() + " - " + event.getEndDate());
        holder.eventTitle.setText(event.getTitle());
        holder.eventLocation.setText(event.getLocation().getAddress() + ", " + event.getLocation().getCity() + ", " + event.getLocation().getState() + " " + event.getLocation().getZip());
    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }

    public static class FavouriteEventViewHolder extends RecyclerView.ViewHolder {
        ImageView eventImage;
        TextView eventDateTime;
        TextView eventTitle;
        TextView eventLocation;
        ImageView eventFavorite;

        public FavouriteEventViewHolder(@NonNull View itemView) {
            super(itemView);
            eventImage = itemView.findViewById(R.id.event_image);
            eventDateTime = itemView.findViewById(R.id.event_date_time);
            eventTitle = itemView.findViewById(R.id.event_title);
            eventLocation = itemView.findViewById(R.id.event_location);
            eventFavorite = itemView.findViewById(R.id.event_favorite);
        }
    }
}