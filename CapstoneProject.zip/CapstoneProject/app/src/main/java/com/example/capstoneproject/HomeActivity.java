package com.example.capstoneproject;

import android.Manifest;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
public class HomeActivity extends AppCompatActivity {

    private EventAdapter eventAdapter;
    private List<Event> eventList = new ArrayList<>();
    private List<Event> filteredList = new ArrayList<>();
    private EditText searchBar;
    private ActivityResultLauncher<String[]> requestPermissionsLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);

        // Register the activity result launcher for permission requests
        requestPermissionsLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestMultiplePermissions(),
                result -> {
                    for (Map.Entry<String, Boolean> entry : result.entrySet()) {
                        String permission = entry.getKey();
                        Boolean isGranted = entry.getValue();
                        if (isGranted) {
                            // Permission is granted
                            Toast.makeText(this, permission + " granted", Toast.LENGTH_SHORT).show();
                        } else {
                            // Permission is denied
                            Toast.makeText(this, permission + " denied", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
        );

        // Request permissions if needed
        requestPermissionsIfNeeded();

        FloatingActionButton fabAdd = findViewById(R.id.fab_add);
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        searchBar = findViewById(R.id.search_bar);

        // Set up RecyclerView with GridLayoutManager
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 2); // 2 columns
        recyclerView.setLayoutManager(gridLayoutManager);

        // Initialize Retrofit
        ApiService apiService = RetrofitClient.getClient().create(ApiService.class);

        // Fetch events from the database
        apiService.getEvents().enqueue(new Callback<List<Event>>() {
            @Override
            public void onResponse(Call<List<Event>> call, Response<List<Event>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    eventList = response.body();
                    filteredList.addAll(eventList);
                    eventAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<List<Event>> call, Throwable t) {
                // Handle failure
            }
        });

        // Set adapter
        eventAdapter = new EventAdapter(filteredList, event -> {
            if (FavoriteManager.getInstance().isFavorite(event)) {
                FavoriteManager.getInstance().removeFavorite(event);
            } else {
                FavoriteManager.getInstance().addFavorite(event);
            }
            filter(searchBar.getText().toString());
        });
        recyclerView.setAdapter(eventAdapter);

        // FloatingActionButton click listener
        fabAdd.setOnClickListener(view -> {
            Intent intent = new Intent(HomeActivity.this, AddEventActivity.class);
            startActivity(intent);
        });

        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.navigation_home) {
                return true;
            } else if (itemId == R.id.navigation_explore) {
                startActivity(new Intent(HomeActivity.this, ExploreActivity.class));
                return true;
            } else if (itemId == R.id.navigation_favourites) {
                startActivity(new Intent(HomeActivity.this, FavouriteActivity.class));
                return true;
            }
            return false;
        });

        // Add TextWatcher to search bar
        searchBar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                filter(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
    }

    private void filter(String text) {
        filteredList.clear();
        for (Event event : eventList) {
            if (event.getTitle().toLowerCase().contains(text.toLowerCase()) ||
                    event.getLocation().getCity().toLowerCase().contains(text.toLowerCase())) {
                filteredList.add(event);
            }
        }
        eventAdapter.updateData(filteredList);
    }

    private void requestPermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            requestPermissionsLauncher.launch(new String[]{
                    Manifest.permission.READ_MEDIA_IMAGES,
                    Manifest.permission.READ_MEDIA_VIDEO,
                    "android.permission.READ_MEDIA_VISUAL_USER_SELECTED"
            });
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissionsLauncher.launch(new String[]{
                    Manifest.permission.READ_MEDIA_IMAGES,
                    Manifest.permission.READ_MEDIA_VIDEO
            });
        } else {
            requestPermissionsLauncher.launch(new String[]{
                    Manifest.permission.READ_EXTERNAL_STORAGE
            });
        }
    }
}
